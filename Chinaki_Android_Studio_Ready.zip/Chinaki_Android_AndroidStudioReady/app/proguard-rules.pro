# Chinaki release rules.
