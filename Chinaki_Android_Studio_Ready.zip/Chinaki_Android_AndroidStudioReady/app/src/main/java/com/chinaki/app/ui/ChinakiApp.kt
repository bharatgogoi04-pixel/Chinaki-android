package com.chinaki.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.chinaki.app.data.repository.ChinakiRepository
import com.chinaki.app.ui.navigation.ChinakiNavHost
import com.chinaki.app.ui.navigation.ChinakiShell

@Composable
fun ChinakiApp() {
    val navController = rememberNavController()
    val repository = remember { ChinakiRepository() }

    Scaffold(
        bottomBar = {
            ChinakiShell(
                navController = navController,
                onCreate = { navController.navigate("create") }
            )
        }
    ) { padding ->
        ChinakiNavHost(
            navController = navController,
            repository = repository,
            modifier = Modifier.padding(padding)
        )
    }
}
