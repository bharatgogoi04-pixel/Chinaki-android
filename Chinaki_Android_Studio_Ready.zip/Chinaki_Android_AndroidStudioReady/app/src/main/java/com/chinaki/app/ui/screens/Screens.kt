package com.chinaki.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.chinaki.app.data.model.*
import com.chinaki.app.data.repository.ChinakiRepository
import com.chinaki.app.ui.navigation.Routes

@Composable
private fun ScreenTitle(title: String, subtitle: String? = null) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun LoginScreen(onLogin: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("চিনাকী", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
        Text("Chinaki", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        Text("Connect. Discover. Share.", style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(32.dp))
        Button(onClick = onLogin, modifier = Modifier.fillMaxWidth()) { Text("Continue in Demo") }
    }
}

@Composable
fun HomeScreen(repo: ChinakiRepository, nav: NavHostController) {
    LazyColumn {
        item { ScreenTitle("Chinaki", "Your social feed") }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { nav.navigate(Routes.EXPLORE) }) { Text("Explore") }
                OutlinedButton(onClick = { nav.navigate(Routes.NEARBY) }) { Text("Nearby") }
                OutlinedButton(onClick = { nav.navigate(Routes.NOTIFICATIONS) }) { Text("Alerts") }
            }
        }
        items(repo.posts()) { post -> PostCard(post) }
    }
}

@Composable
private fun PostCard(post: Post) {
    Card(
        Modifier.fillMaxWidth().padding(12.dp),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column {
            Box(
                Modifier.fillMaxWidth().height(210.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) { Text(post.imageLabel, style = MaterialTheme.typography.headlineSmall) }
            Column(Modifier.padding(16.dp)) {
                Text(post.author.name + "  " + post.author.handle, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(post.caption)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    Text("♥ ${post.likes}")
                    Text("💬 ${post.comments}")
                    Text("↗ Share")
                }
            }
        }
    }
}

@Composable
fun ReelsScreen(repo: ChinakiRepository) {
    LazyColumn {
        item { ScreenTitle("Reels", "Short videos") }
        items(repo.reels()) { reel ->
            Card(Modifier.fillMaxWidth().padding(12.dp)) {
                Column {
                    Box(
                        Modifier.fillMaxWidth().height(360.dp).background(MaterialTheme.colorScheme.inverseSurface),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.PlayCircle, null, tint = MaterialTheme.colorScheme.inverseOnSurface, modifier = Modifier.size(64.dp))
                    }
                    Column(Modifier.padding(16.dp)) {
                        Text(reel.author.name, fontWeight = FontWeight.Bold)
                        Text(reel.caption)
                        Text(reel.views, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun ExploreScreen(nav: NavHostController) {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTitle("Explore", "Search and discovery")
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search people, posts, places…") }, singleLine = true)
        Spacer(Modifier.height(16.dp))
        Text("Categories", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AssistChip(onClick = {}, label = { Text("Trending") })
            AssistChip(onClick = {}, label = { Text("Music") })
            AssistChip(onClick = { nav.navigate(Routes.NEARBY) }, label = { Text("Nearby") })
        }
    }
}

@Composable
fun NearbyScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTitle("Nearby", "Discover people and places around you")
        Card(Modifier.fillMaxWidth().height(260.dp)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.LocationOn, null, modifier = Modifier.size(56.dp))
                Text("Nearby map / discovery will appear here", Modifier.padding(top = 90.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Location access can be connected when the backend and permissions are enabled.")
    }
}

@Composable
fun CreateScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTitle("Create", "Share something with Chinaki")
        Button(onClick = {}, Modifier.fillMaxWidth()) { Icon(Icons.Default.PhotoLibrary, null); Spacer(Modifier.width(8.dp)); Text("Choose from Gallery") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = {}, Modifier.fillMaxWidth()) { Icon(Icons.Default.CameraAlt, null); Spacer(Modifier.width(8.dp)); Text("Open Camera") }
        Spacer(Modifier.height(18.dp))
        var caption by remember { mutableStateOf("") }
        OutlinedTextField(caption, { caption = it }, Modifier.fillMaxWidth().height(140.dp), placeholder = { Text("Write a caption…") })
        Spacer(Modifier.height(12.dp))
        Button(onClick = {}, Modifier.fillMaxWidth()) { Text("Post") }
    }
}

@Composable
fun ChatScreen(repo: ChinakiRepository) {
    LazyColumn {
        item { ScreenTitle("Chat", "Messages") }
        items(repo.chats()) { chat ->
            ListItem(
                headlineContent = { Text(chat.user.name, fontWeight = FontWeight.Bold) },
                supportingContent = { Text(chat.lastMessage) },
                leadingContent = { Icon(Icons.Default.AccountCircle, null, modifier = Modifier.size(42.dp)) },
                trailingContent = { if (chat.unread > 0) Badge { Text(chat.unread.toString()) } }
            )
            HorizontalDivider()
        }
    }
}

@Composable
fun NotificationsScreen(repo: ChinakiRepository) {
    LazyColumn {
        item { ScreenTitle("Notifications") }
        items(repo.notifications()) { n ->
            ListItem(
                headlineContent = { Text(n.title, fontWeight = FontWeight.Bold) },
                supportingContent = { Text("${n.body} • ${n.time}") },
                leadingContent = { Icon(Icons.Default.Notifications, null) }
            )
            HorizontalDivider()
        }
    }
}

@Composable
fun ProfileScreen(repo: ChinakiRepository) {
    var assamese by remember { mutableStateOf(false) }
    val user = repo.currentUser()
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        ScreenTitle("Profile", "Identity, stats and settings")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AccountCircle, null, Modifier.size(80.dp))
            Spacer(Modifier.width(16.dp))
            Column {
                Text(user.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(user.handle)
                Text(user.bio)
            }
        }
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stat("Posts", "24")
            Stat("Followers", user.followers.toString())
            Stat("Following", user.following.toString())
        }
        Spacer(Modifier.height(24.dp))
        Card(Modifier.fillMaxWidth()) {
            ListItem(
                headlineContent = { Text("Language") },
                supportingContent = { Text(if (assamese) "অসমীয়া" else "English") },
                trailingContent = {
                    Switch(checked = assamese, onCheckedChange = { assamese = it })
                }
            )
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = {}, Modifier.fillMaxWidth()) { Text("Edit Profile") }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold)
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
