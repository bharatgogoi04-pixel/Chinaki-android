package com.chinaki.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.chinaki.app.ui.ChinakiApp
import com.chinaki.app.ui.theme.ChinakiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ChinakiTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ChinakiApp()
                }
            }
        }
    }
}
