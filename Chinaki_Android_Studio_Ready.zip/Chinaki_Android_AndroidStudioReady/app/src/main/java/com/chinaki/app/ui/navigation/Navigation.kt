package com.chinaki.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.chinaki.app.data.repository.ChinakiRepository
import com.chinaki.app.ui.screens.*

data class NavItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun ChinakiNavHost(
    navController: NavHostController,
    repository: ChinakiRepository,
    modifier: Modifier = Modifier
) {
    NavHost(navController, startDestination = Routes.HOME, modifier = modifier) {
        composable(Routes.LOGIN) { LoginScreen { navController.navigate(Routes.HOME) { popUpTo(Routes.LOGIN) { inclusive = true } } } }
        composable(Routes.HOME) { HomeScreen(repository, navController) }
        composable(Routes.REELS) { ReelsScreen(repository) }
        composable(Routes.EXPLORE) { ExploreScreen(navController) }
        composable(Routes.NEARBY) { NearbyScreen() }
        composable(Routes.CREATE) { CreateScreen() }
        composable(Routes.CHAT) { ChatScreen(repository) }
        composable(Routes.NOTIFICATIONS) { NotificationsScreen(repository) }
        composable(Routes.PROFILE) { ProfileScreen(repository) }
    }
}

@Composable
fun ChinakiShell(navController: NavHostController, onCreate: () -> Unit) {
    val items = listOf(
        NavItem(Routes.HOME, "Home", Icons.Default.Home),
        NavItem(Routes.REELS, "Reels", Icons.Default.PlayArrow),
        NavItem(Routes.EXPLORE, "Explore", Icons.Default.Search),
        NavItem(Routes.CREATE, "Create", Icons.Default.AddCircle),
        NavItem(Routes.CHAT, "Chat", Icons.Default.Chat),
        NavItem(Routes.PROFILE, "Profile", Icons.Default.Person)
    )
    val current = navController.currentBackStackEntry?.destination?.route

    NavigationBar {
        items.forEach { item ->
            NavigationBarItem(
                selected = current == item.route,
                onClick = {
                    navController.navigate(item.route) {
                        popUpTo(Routes.HOME)
                        launchSingleTop = true
                    }
                },
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label) }
            )
        }
    }
}
