package com.chinaki.app.data.local

import com.chinaki.app.data.model.*

object DemoData {
    val me = User("me", "Bharat", "@bharat", "Building Chinaki", 1280, 312)

    private val users = listOf(
        User("u1", "Priya", "@priya", "Assam vibes", 9200, 410),
        User("u2", "Rohan", "@rohan", "Travel • Music", 3400, 201),
        User("u3", "Maya", "@maya", "Creator", 12000, 502)
    )

    val posts = listOf(
        Post("p1", users[0], "Beautiful morning in Assam ☀️", 1240, 86, "Assam morning"),
        Post("p2", users[1], "Weekend road trip with the crew 🚗", 870, 54, "Road trip"),
        Post("p3", users[2], "New creation is live ✨", 2100, 132, "New creation")
    )

    val reels = listOf(
        Reel("r1", users[0], "A little slice of Assam", "24K views"),
        Reel("r2", users[1], "Road trip transition", "18K views"),
        Reel("r3", users[2], "Creator tips in 15 seconds", "42K views")
    )

    val chats = listOf(
        ChatPreview("c1", users[0], "See you tomorrow!", "10:42", 2),
        ChatPreview("c2", users[1], "That reel is awesome 🔥", "09:15", 0),
        ChatPreview("c3", users[2], "Let's collaborate.", "Yesterday", 1)
    )

    val notifications = listOf(
        NotificationItem("n1", "Priya liked your post", "Beautiful morning in Assam", "2m"),
        NotificationItem("n2", "Rohan started following you", "", "18m"),
        NotificationItem("n3", "Maya mentioned you", "New creation is live", "1h")
    )
}
