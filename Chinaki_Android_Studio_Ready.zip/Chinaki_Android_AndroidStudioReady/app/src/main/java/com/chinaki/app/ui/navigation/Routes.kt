package com.chinaki.app.ui.navigation

object Routes {
    const val LOGIN = "login"
    const val HOME = "home"
    const val REELS = "reels"
    const val EXPLORE = "explore"
    const val NEARBY = "nearby"
    const val CREATE = "create"
    const val CHAT = "chat"
    const val NOTIFICATIONS = "notifications"
    const val PROFILE = "profile"
}
