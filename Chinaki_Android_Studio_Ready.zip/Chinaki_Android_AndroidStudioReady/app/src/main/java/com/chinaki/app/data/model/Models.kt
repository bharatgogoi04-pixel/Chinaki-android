package com.chinaki.app.data.model

data class User(
    val id: String,
    val name: String,
    val handle: String,
    val bio: String = "",
    val followers: Int = 0,
    val following: Int = 0
)

data class Post(
    val id: String,
    val author: User,
    val caption: String,
    val likes: Int,
    val comments: Int,
    val imageLabel: String,
    val liked: Boolean = false
)

data class Reel(
    val id: String,
    val author: User,
    val caption: String,
    val views: String
)

data class ChatPreview(
    val id: String,
    val user: User,
    val lastMessage: String,
    val time: String,
    val unread: Int
)

data class NotificationItem(
    val id: String,
    val title: String,
    val body: String,
    val time: String
)
