package com.chinaki.app.data.repository

import com.chinaki.app.data.local.DemoData
import com.chinaki.app.data.model.*
import com.chinaki.app.data.remote.ApiClient

class ChinakiRepository(
    private val apiClient: ApiClient = ApiClient()
) {
    val isDemoMode get() = apiClient.isDemoMode

    fun currentUser(): User = DemoData.me
    fun posts(): List<Post> = DemoData.posts
    fun reels(): List<Reel> = DemoData.reels
    fun chats(): List<ChatPreview> = DemoData.chats
    fun notifications(): List<NotificationItem> = DemoData.notifications
}
