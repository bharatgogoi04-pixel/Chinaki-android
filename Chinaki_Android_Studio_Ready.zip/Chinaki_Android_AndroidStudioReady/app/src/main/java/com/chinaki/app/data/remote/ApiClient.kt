package com.chinaki.app.data.remote

import com.chinaki.app.BuildConfig

class ApiClient {
    val baseUrl: String = BuildConfig.API_BASE_URL

    val isDemoMode: Boolean
        get() = baseUrl.isBlank()

    // REST endpoints can be added here as the backend is implemented.
    // Demo mode intentionally remains available when API_BASE_URL is empty.
}
