# Chinaki Android v2

A complete Jetpack Compose starter project based on `CHINAKI_V2_ARCHITECTURE.md`.

## Included
- Single-activity Jetpack Compose architecture
- Navigation Compose
- Login
- Home feed
- Reels
- Explore
- Nearby
- Create
- Chat
- Notifications
- Profile
- Assamese / English language selector
- Demo repository with local sample data
- REST client abstraction using `BuildConfig.API_BASE_URL`
- Demo mode when `CHINAKI_API_BASE_URL` is empty
- Material 3 UI and reusable bottom navigation Shell

## Build
Open this folder in Android Studio (Ladybug or newer), let Gradle sync, then run the `app` configuration.

The project uses:
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.21
- Compose BOM 2024.12.01
- Java/Kotlin JVM target 17

## API configuration
Create `local.properties` in the project root and add:

CHINAKI_API_BASE_URL=https://your-api.example.com/

If the value is empty or absent, the app remains in demo mode.

## Package
`com.chinaki.app`

## Architecture
ui/navigation, ui/home, ui/reels, ui/explore, ui/create, ui/chat, ui/profile,
data/model, data/repository, data/remote, data/local.


## Android Studio prerequisites
- Android Studio with Android SDK Platform 35
- JDK 17
- Gradle 8.7 via the included wrapper configuration
- Internet access for the first dependency sync

The app is configured to run in demo mode without a backend.
