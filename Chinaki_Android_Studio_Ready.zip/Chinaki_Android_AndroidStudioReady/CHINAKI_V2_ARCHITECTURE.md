# Chinaki v2 Architecture

## Navigation
Single-activity Jetpack Compose architecture with Navigation Compose.

Routes:
- login
- home
- reels
- explore
- nearby
- create
- chat
- notifications
- profile

The existing MainActivity already defines these destinations and a reusable Shell with bottom navigation.

## v2 screen responsibilities
- Home: feed, post cards, reactions and discovery entry points.
- Reels: full-screen vertical short-video experience.
- Explore: search, discovery categories and Nearby entry.
- Create: gallery/camera selection, caption and post action.
- Chat: conversation list and message experience.
- Profile: identity, stats, edit profile and language selector.

## Architecture direction
Recommended next extraction:
ui/navigation, ui/home, ui/reels, ui/explore, ui/create, ui/chat, ui/profile,
data/model, data/repository, data/remote, data/local.

Keep demo mode working when CHINAKI_API_BASE_URL is empty. The existing REST client uses BuildConfig.API_BASE_URL.
