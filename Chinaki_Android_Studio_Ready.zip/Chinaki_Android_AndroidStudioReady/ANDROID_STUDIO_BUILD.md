# Chinaki — Android Studio first-build guide

1. Open the `Chinaki_Android` folder in Android Studio.
2. Use a JDK 17 runtime for Gradle.
3. Allow Android Studio to install/sync the required Android SDK components.
4. Leave `CHINAKI_API_BASE_URL` unset for demo mode.
5. Run the `app` configuration on an Android 7.0+ emulator/device.
6. For a debug APK use **Build > Generate App Bundles or APKs > Generate APKs** (menu wording can vary by Android Studio version).

Expected APK:
`app/build/outputs/apk/debug/app-debug.apk`

The project is intentionally demo-first. Backend endpoints are not required for the first launch.
